from flask import Flask
app = Flask(__name__)
#Secret key would go here --- app.secret_key = 'dsjlk2j3k2j3ioe' the more complex, the safe it is. 

